const openBtn = document.getElementById("openLetterBtn");
const envelope = document.getElementById("envelope");
const envelopeTop = document.getElementById("envelopeTop");
const letterPaper = document.getElementById("letterPaper");
const emojiBtn = document.getElementById("emojiBtn");
const chatBubble = document.getElementById("chatBubble");

openBtn.addEventListener("click", () => {
  envelope.style.transform = "scale(1)";
  openBtn.style.display = "none";
});

envelopeTop.addEventListener("click", () => {
  envelopeTop.style.transform = "rotateX(-180deg)";
  letterPaper.style.transform = "translateY(0)";
  setTimeout(() => {
    document.getElementById("emojiSection").scrollIntoView({ behavior: "smooth" });
  }, 1200);
});

emojiBtn.addEventListener("click", () => {
  chatBubble.style.display = "inline-block";
});
function spawnFloatingHearts() {
  for (let i = 0; i < 25; i++) {
    const heart = document.createElement("div");
    heart.classList.add("floating-heart");
    heart.textContent = "💌";
    heart.style.top = `${Math.random() * 100}vh`;
    heart.style.left = `${Math.random() * 100}vw`;
    heart.style.animationDelay = `${Math.random() * 8}s`;
    document.body.appendChild(heart);
  }
}

spawnFloatingHearts(); // start on page load